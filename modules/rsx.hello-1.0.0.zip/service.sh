#!/system/bin/sh
echo "rsx.hello module loaded"
